import { RowDataPacket } from 'mysql2';
import { Pessoa } from './pessoa.model';

export interface IVendedor extends RowDataPacket {
    id?: number;
    nome?: string;
    email?: string;
}

export class Vendedor extends Pessoa {

    private _id?: number;

    constructor(nome: string, email: string, id?: number,) {
        super(nome, email);

        this._id = id;
    }


    //GETTERS
    public get Id(): number | undefined {
        return this._id;
    }

    public get Nome(): string | undefined {
        return this._nome;
    }

    public get Email(): string | undefined {
        return this._email;
    }


    //SETTERS
    public set Nome(value: string) {
        this._validarNome(value);
        this._nome = value;
    }


    mostrarDados(): string {
        return `Nome: ${this.Nome}| Email: ${this.Email}`;
    }

    // DP => FACTORY
    public static inserir(nome: string, email: string): Vendedor {
        return new Vendedor(nome, email);
    }

    public static alterar(nome: string, email: string, id: number) {
        return new Vendedor(nome, email, id);
    }


    private _validarNome(value: string): void {
        if (!value || value.trim().length < 3) {
            throw new Error('Nome do Vendedor deve ter pelo menos 3 caracteres')
        }
        if (value.trim().length > 45) {
            throw new Error('Nome deve ter no maximo 45 caracteres')
        }
    }

}